#fileName = input("Enter file name: ")
 #Open file for input
#f = open(fileName, "r")
while True:
    fileName = input("Enter file name: ")
    # Open file for input
    f = open(fileName, "r")
    if fileName.endswith((".txt")):
        for line in f:
            print(line)
        break
    else:
        print("Extension must be a .txt file")